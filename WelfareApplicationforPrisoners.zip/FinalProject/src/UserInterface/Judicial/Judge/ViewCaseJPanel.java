/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package UserInterface.Judicial.Judge;

import Business.Case.PrisonerCase;
import Business.EcoSystem;
import Business.Enterprise.Enterprise;
import Business.Job.Job;
import Business.Network.Network;
import Business.Organization.Organization;
import Business.Organization.PrisonerOrganization;
import Business.Prisoner.Prisoner;
import Business.WorkQueue.CaseWorkRequest;
import Business.WorkQueue.WorkRequest;
import java.awt.CardLayout;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

/**
 *
 * @author rishi
 */
public class ViewCaseJPanel extends javax.swing.JPanel {

    /**
     * Creates new form ViewCaseJPanel
     */
    Prisoner p;
    String message;
    JPanel userProcessContainer;
    EcoSystem system;
    ArrayList<Prisoner> prisonerList = null;
    String caseType;

    public ViewCaseJPanel(JPanel userProcessContainer, Prisoner prisoner, CaseWorkRequest request, EcoSystem system, String caseType) {
        initComponents();
        this.userProcessContainer = userProcessContainer;
        this.p = prisoner;
        this.message = request.getCaseMessage();
        this.system = system;
        this.caseType = caseType;
        fetchPrisonerJobNo();

        SimpleDateFormat sdf = new SimpleDateFormat("MM-dd-yyyy");
        lblCrimeDescription.setText(p.getCrimeDescription());
        lblCrimeLevel.setText(Integer.toString(p.getCrimeLevel()));
        lblPrisonerName.setText(p.getPrisonerName());
        lblPrisonerAge.setText(Integer.toString(p.getAge()));
        lblNoOfKids.setText(Integer.toString(p.getNoOfKids()));
        lblNoOfComplains.setText(Integer.toString(p.getNoOfComplains()));
        lblPrisonerName.setText(p.getPrisonerName());
        lblMentalStabilityIndex.setText(Float.toString(p.getMentalStabilityIndex()));
        lblGoodBehaviourIndex.setText(Float.toString(p.getGoodBehaviourIndex()));
        lblAdmissionDate.setText(sdf.format(p.getAdmitDate()));
        lbreleaseDate.setText(sdf.format(p.getReleaseDate()));
        txtMessage.setText(message);

        if (p.isMaritialStatus()) {
            lblMartialStatus.setText("Married");
        } else {
            lblMartialStatus.setText("Unmarried");
        }
    }

    public void fetchPrisonerJobNo() {
        prisonerList = new ArrayList<Prisoner>();
        String enterpriseName = null;
        for (Network n : system.getNetworkList()) {
            for (Enterprise e : n.getEnterpriseDirectory().getEnterpriseList()) {
                for (Organization org : e.getOrganizationDirectory().getOrganizationList()) {
                    if (org instanceof PrisonerOrganization) {
                        for (Prisoner p : org.getPrisonerDirectory().getPrisonerList()) {
                            if (p.getPrisonerName().equals(p.getPrisonerName())) {
                                enterpriseName = e.getName();
                                // return;
                            }
                        }
                    }
                }
            }
        }
        for (Network n : system.getNetworkList()) {
            for (Enterprise e : n.getEnterpriseDirectory().getEnterpriseList()) {
                if (e.getName().equals(enterpriseName)) {
                    for (Organization org : e.getOrganizationDirectory().getOrganizationList()) {
                        if (org instanceof PrisonerOrganization) {
                            for (Prisoner p : org.getPrisonerDirectory().getPrisonerList()) {
                                prisonerList.add(p);
                            }
                        }
                    }
                }
            }
        }
    }

    public void assessPrisonerForParole() {
        p.setTotalPoints(0);
        float total = p.getTotalPoints();

        int noOfJobs = 0;

        for (Prisoner pr : prisonerList) {
            noOfJobs = noOfJobs + pr.getNoOfJobs();
        }
        noOfJobs = noOfJobs / prisonerList.size();
        float jobIndex = p.getJobPoints() / p.getNoOfJobs();

        jobIndex = (jobIndex * p.getNoOfJobs()) / noOfJobs;

        if (p.getNoOfKids() >= 3) {
            total = total + 5;
        } else {
            if ((p.getNoOfKids() < 3) && (p.getNoOfKids() > 0)) {
                total = total + 2;
            } else {
                total = total + 0;
            }
        }

        if (p.isMaritialStatus() == true) {
            total = total + 5;
        } else {
            total = total + 2;
        }

        if (p.getCrimeLevel() == 1) {
            total = total + 10;
        } else {
            total = total + 5;
        }

        if ((p.getAge() >= 18) && (p.getAge() < 30)) {
            total = total + 5;
        } else {
            if ((p.getAge() < 60) && (p.getAge() >= 30)) {
                total = total + 10;
            } else {
                total = total + 5;
            }
        }

        total = total + p.getMentalStabilityIndex();
        total = total + p.getGoodBehaviourIndex();
        total = total + jobIndex;

        if (total > 65.00) {
            if (p.getNoOfComplains() > 3) {
                JOptionPane.showMessageDialog(null, "Eligible for Parole. However, kindly discuss the no of complaints registered against him (i.e. " + p.getNoOfComplains() + ")");
            } else {
                JOptionPane.showMessageDialog(null, "Definitely Eligible for Parole");
            }
        } else {
            JOptionPane.showMessageDialog(null, "Not eligible for Parole. However decision is in your court");
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")

    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblPrisonerName = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        lblCrimeDescription = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        txtMessage = new javax.swing.JTextField();
        lblAdmissionDate = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        lblCrimeLevel = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        btnAssessPrisoner = new javax.swing.JButton();
        btnGrantParole = new javax.swing.JButton();
        btnReject = new javax.swing.JButton();
        btnAdjournHearing = new javax.swing.JButton();
        jLabel11 = new javax.swing.JLabel();
        lblNoOfKids = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        lbreleaseDate = new javax.swing.JLabel();
        lblPrisonerAge = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        lblMartialStatus = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        lblMentalStabilityIndex = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        lblGoodBehaviourIndex = new javax.swing.JLabel();
        lblNoOfComplains = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        btnBack = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        dtDate = new org.jdesktop.swingx.JXDatePicker();

        setMaximumSize(new java.awt.Dimension(900, 700));
        setMinimumSize(new java.awt.Dimension(100, 200));
        setPreferredSize(new java.awt.Dimension(900, 700));
        setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblPrisonerName.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        lblPrisonerName.setText("<Prisoner Name>");
        add(lblPrisonerName, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 110, 170, 27));

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel3.setText("Prisoner Name");
        add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(136, 106, 190, 27));

        jLabel10.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel10.setText("Crime Description");
        add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(138, 151, 170, 31));

        lblCrimeDescription.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        lblCrimeDescription.setText("<Crime Description>");
        add(lblCrimeDescription, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 150, -1, 31));

        jLabel9.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel9.setText("Crime Level");
        add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 210, 120, 31));

        txtMessage.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        add(txtMessage, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 420, 504, 110));

        lblAdmissionDate.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        lblAdmissionDate.setText("<Admission Datel>");
        add(lblAdmissionDate, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 260, 180, 31));

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel1.setText("Message for Judge");
        add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 490, 170, 21));

        lblCrimeLevel.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        lblCrimeLevel.setText("<Crime Level>");
        add(lblCrimeLevel, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 210, 150, 31));

        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel7.setText("Admission Date");
        add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(138, 259, 170, 31));

        btnAssessPrisoner.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        btnAssessPrisoner.setText("Assess Prisoner");
        btnAssessPrisoner.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAssessPrisonerActionPerformed(evt);
            }
        });
        add(btnAssessPrisoner, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 440, -1, -1));

        btnGrantParole.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        btnGrantParole.setText("Grant Parole");
        btnGrantParole.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGrantParoleActionPerformed(evt);
            }
        });
        add(btnGrantParole, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 640, 150, -1));

        btnReject.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        btnReject.setText("Reject Application");
        btnReject.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRejectActionPerformed(evt);
            }
        });
        add(btnReject, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 640, -1, -1));

        btnAdjournHearing.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        btnAdjournHearing.setText("Adjourn Hearing");
        btnAdjournHearing.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAdjournHearingActionPerformed(evt);
            }
        });
        add(btnAdjournHearing, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 640, -1, -1));

        jLabel11.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel11.setText("No of Kids");
        add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 150, 100, 31));

        lblNoOfKids.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        lblNoOfKids.setText("<Crime Description>");
        add(lblNoOfKids, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 150, 200, 31));

        jLabel12.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel12.setText("Age");
        add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 210, 150, 31));

        lbreleaseDate.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        lbreleaseDate.setText("<Release Date>");
        add(lbreleaseDate, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 260, 180, 31));

        lblPrisonerAge.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        lblPrisonerAge.setText("<Crime Level>");
        add(lblPrisonerAge, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 210, 140, 31));

        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel8.setText("Release Date");
        add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 260, 190, 31));

        lblMartialStatus.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        lblMartialStatus.setText("<Prisoner Name>");
        add(lblMartialStatus, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 110, 170, 27));

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel4.setText("Maritial Status");
        add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 110, 130, 27));

        jLabel13.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel13.setText("Mental Stability Index");
        add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(136, 333, 210, 31));

        lblMentalStabilityIndex.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        lblMentalStabilityIndex.setText("<MEntal Stability Index>");
        add(lblMentalStabilityIndex, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 330, 230, 31));

        jLabel14.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel14.setText("Good behaviour Index");
        add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 330, 220, 31));

        lblGoodBehaviourIndex.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        lblGoodBehaviourIndex.setText("<Good Behaviour Index>");
        add(lblGoodBehaviourIndex, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 330, 240, 31));

        lblNoOfComplains.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        lblNoOfComplains.setText("<No of Complains>");
        add(lblNoOfComplains, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 390, 240, 21));

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel5.setText("No of Complains");
        add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(137, 394, 160, 21));

        btnBack.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        btnBack.setText("<< Back");
        btnBack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBackActionPerformed(evt);
            }
        });
        add(btnBack, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel6.setText("View Case Details");
        add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 30, -1, -1));
        add(dtDate, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 570, 180, -1));
    }// </editor-fold>//GEN-END:initComponents

    public void assessPrisonerForRelease() {
        p.setTotalPoints(0);
        float total = p.getTotalPoints();

        if (p.getNoOfKids() >= 3) {
            total = total + 5;
        } else {
            if ((p.getNoOfKids() < 3) && (p.getNoOfKids() > 0)) {
                total = total + 2;
            } else {
                total = total + 0;
            }
        }

        int noOfJobs = 0;

        for (Prisoner pr : prisonerList) {
            noOfJobs = noOfJobs + pr.getNoOfJobs();
        }
        float jobIndex = p.getJobPoints() / p.getNoOfJobs();
        jobIndex = (jobIndex * p.getNoOfJobs()) / noOfJobs;

        if (p.isMaritialStatus() == true) {
            total = total + 5;
        } else {
            total = total + 2;
        }

        if (p.getCrimeLevel() == 1) {
            total = total + 10;
        } else {
            total = total + 5;
        }

        if ((p.getAge() >= 18) && (p.getAge() < 30)) {
            total = total + 5;
        } else {
            if ((p.getAge() < 60) && (p.getAge() >= 30)) {
                total = total + 5;
            } else {
                total = total + 10;
            }
        }

        total = total + jobIndex;
        total = total + p.getMentalStabilityIndex();
        total = total + p.getGoodBehaviourIndex();

        if (p.getMentalStabilityIndex() < 20 || p.getGoodBehaviourIndex() < 20) {
            total = 0;
        }

        if (total > 70.00) {
            if (p.getNoOfComplains() > 3) {
                JOptionPane.showMessageDialog(null, "Eligible for Release. However, kindly discuss the no of complaints registered against him (i.e. " + p.getNoOfComplains() + ")");
            } else {
                JOptionPane.showMessageDialog(null, "Definitely Eligible for Early Release");
            }
        } else {
            JOptionPane.showMessageDialog(null, "Not eligible for Parole. However decision is in your court");
        }
    }
    private void btnAssessPrisonerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAssessPrisonerActionPerformed
        // TODO add your handling code here:

        if (caseType.equals("Parole")) {
            assessPrisonerForParole();
        }
        if (caseType.equals("Early Release")) {
            assessPrisonerForRelease();
        }

    }//GEN-LAST:event_btnAssessPrisonerActionPerformed

    private void btnBackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackActionPerformed
        // TODO add your handling code here:
        userProcessContainer.remove(this);
        CardLayout layout = (CardLayout) userProcessContainer.getLayout();
        layout.previous(userProcessContainer);
    }//GEN-LAST:event_btnBackActionPerformed

    private void btnAdjournHearingActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAdjournHearingActionPerformed
        // TODO add your handling code here:
        SimpleDateFormat sdf = new SimpleDateFormat("MM-dd-yyyy");
        Date d = new Date();
        Date date = null;
        String temp1Date = sdf.format(dtDate.getDate());
        if (temp1Date != null) {
            for (WorkRequest request : system.getWorkQueue().getWorkRequestList()) {
                if (request instanceof CaseWorkRequest) {
                    if (((CaseWorkRequest) request).getPrisoner().getPrisonerName().equals(p.getPrisonerName())) {
                        request.setStatus("Case hearing adjourn to " + temp1Date);
                    }
                }
            }
            JOptionPane.showMessageDialog(null, "Case hearing adjourn.");
        }
        else if(dtDate.getDate().before(date))
        {
            JOptionPane.showMessageDialog(null,"Please select future date.");
        }
        else{
            JOptionPane.showMessageDialog(null,"Please select date.");
        }
    }//GEN-LAST:event_btnAdjournHearingActionPerformed

    private void btnGrantParoleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGrantParoleActionPerformed
        // TODO add your handling code here:
        for (WorkRequest request : system.getWorkQueue().getWorkRequestList()) {
            if (request instanceof CaseWorkRequest) {
                if (((CaseWorkRequest) request).getPrisoner().getPrisonerName().equals(p.getPrisonerName())) {
                    request.setStatus("Parole Accepted");
                }
            }
        }

        for (Network n : system.getNetworkList()) {
            for (Enterprise e : n.getEnterpriseDirectory().getEnterpriseList()) {
                for (Organization org : e.getOrganizationDirectory().getOrganizationList()) {
                    if (org instanceof PrisonerOrganization) {
                        for (Prisoner p : org.getPrisonerDirectory().getPrisonerList()) {
                            if (p.getPrisonerName().equals(p.getPrisonerName())) {
                                p.setOnParole(true);
                            }
                        }
                    }
                }
            }

        }
        JOptionPane.showMessageDialog(null, "Parole request accepted.");
    }//GEN-LAST:event_btnGrantParoleActionPerformed

    private void btnRejectActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRejectActionPerformed
        // TODO add your handling code here:
        for (WorkRequest request : system.getWorkQueue().getWorkRequestList()) {
            if (request instanceof CaseWorkRequest) {
                if (((CaseWorkRequest) request).getPrisoner().getPrisonerName().equals(p.getPrisonerName())) {
                    request.setStatus("Parole Rejected");
                }
            }
        }

        for (Network n : system.getNetworkList()) {
            for (Enterprise e : n.getEnterpriseDirectory().getEnterpriseList()) {
                for (Organization org : e.getOrganizationDirectory().getOrganizationList()) {
                    if (org instanceof PrisonerOrganization) {
                        for (Prisoner p : org.getPrisonerDirectory().getPrisonerList()) {
                            if (p.getPrisonerName().equals(p.getPrisonerName())) {
                                p.setOnParole(false);
                            }
                        }
                    }
                }
            }

        }
        JOptionPane.showMessageDialog(null, "Application request rejected.");
    }//GEN-LAST:event_btnRejectActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAdjournHearing;
    private javax.swing.JButton btnAssessPrisoner;
    private javax.swing.JButton btnBack;
    private javax.swing.JButton btnGrantParole;
    private javax.swing.JButton btnReject;
    private org.jdesktop.swingx.JXDatePicker dtDate;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JLabel lblAdmissionDate;
    private javax.swing.JLabel lblCrimeDescription;
    private javax.swing.JLabel lblCrimeLevel;
    private javax.swing.JLabel lblGoodBehaviourIndex;
    private javax.swing.JLabel lblMartialStatus;
    private javax.swing.JLabel lblMentalStabilityIndex;
    private javax.swing.JLabel lblNoOfComplains;
    private javax.swing.JLabel lblNoOfKids;
    private javax.swing.JLabel lblPrisonerAge;
    private javax.swing.JLabel lblPrisonerName;
    private javax.swing.JLabel lbreleaseDate;
    private javax.swing.JTextField txtMessage;
    // End of variables declaration//GEN-END:variables
}
