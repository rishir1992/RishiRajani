/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package UserInterface.CustomerRole;

/**
 *
 * @author akuln
 */
import java.net.URLConnection;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.io.InputStreamReader;
import java.io.BufferedReader;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathFactory;
import javax.xml.xpath.XPathConstants;
import org.w3c.dom.Document;
import Business.Customer.Customer;

/**
 * This class will get the lat long values.
 *
 * @author akuln
 */
public class LatLng {

    Customer c;

    public LatLng(String zipcode, Customer c) throws Exception {

        String latLongs[] = getLatLongPositions(zipcode);
        GoogleMapsDemo g = new GoogleMapsDemo(c, latLongs[0], latLongs[1]);
        this.c = c;
        c.setLat(Double.parseDouble(latLongs[0]));
        c.setLongi(Double.parseDouble(latLongs[1]));
        c.setCity(latLongs[2]);
        c.setState(latLongs[3]);
        c.setCountry(latLongs[4]);
        //System.out.println(latLongs[4]);
        //System.out.println("Latitude: " + latLongs[0] + " and Longitude: " + latLongs[1]);
    }

    public static String[] getLatLongPositions(String address) throws Exception {
        int responseCode = 0;
        String api = "http://maps.googleapis.com/maps/api/geocode/xml?address=" + URLEncoder.encode(address, "UTF-8") + "&sensor=true";
        URL url = new URL(api);
        HttpURLConnection httpConnection = (HttpURLConnection) url.openConnection();
        httpConnection.connect();
        responseCode = httpConnection.getResponseCode();
        if (responseCode == 200) {
            DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();;
            Document document = builder.parse(httpConnection.getInputStream());
            XPathFactory xPathfactory = XPathFactory.newInstance();
            XPath xpath = xPathfactory.newXPath();
            XPathExpression expr = xpath.compile("/GeocodeResponse/status");
            String status = (String) expr.evaluate(document, XPathConstants.STRING);
            if (status.equals("OK")) {
                expr = xpath.compile("//geometry/location/lat");
                String latitude = (String) expr.evaluate(document, XPathConstants.STRING);
                //System.out.println(latitude);
                expr = xpath.compile("//geometry/location/lng");
                String longitude = (String) expr.evaluate(document, XPathConstants.STRING);
                //System.out.println(longitude);
                expr = xpath.compile("//formatted_address");
                String Address = (String) expr.evaluate(document, XPathConstants.STRING);
                String city = null;
                String[] s = null;
                String state = null;
                String country = null;
                String[] A = Address.split(",");
                if (A.length > 2) {
                    //System.out.println(A[0]);
                    city = A[0];
                    s = A[1].split(" ");
                    state = s[1];
                    country = A[2];
                }
                return new String[]{latitude, longitude, city, state, country};
            } else {
                throw new Exception("Error from the API - response status: " + status);
            }
        }
        return null;
    }
}
