/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package UserInterface.WardenRole;

import Business.EcoSystem;
import Business.Enterprise.Enterprise;
import Business.Event.Event;
import Business.Organization.Organization;
import Business.Organization.PrisonerOrganization;
import Business.Prisoner.Prisoner;
import java.awt.CardLayout;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Kinjal
 */
public class EvaluatePrisonerJPanel extends javax.swing.JPanel {

    /**
     * Creates new form EvaluatePrisonerJPanel
     */
    JPanel userProcessContainer;
    EcoSystem system;
    Enterprise enterprise;

    Object o;
    Organization org;

    EvaluatePrisonerJPanel(JPanel userProcessContainer, EcoSystem system, Enterprise enterprise) {
        initComponents();
        this.userProcessContainer = userProcessContainer;
        this.system = system;
        this.enterprise = enterprise;
        for (Organization organization : enterprise.getOrganizationDirectory().getOrganizationList()) {
            if (organization instanceof PrisonerOrganization) {
                o = organization;
            }

            org = (Organization) o;
        }
        populateDropdown();
    }

    public void populateDropdown() {
        cbPrisonerName.removeAllItems();
        cbPrisonerName.addItem("");
//        for (Prisoner p : enterprise.getPrisonerDirectory().getPrisonerList()) {
//            cbPrisonerName.addItem(p);
//        }

//        Object o = null;
//        for (Organization organization : enterprise.getOrganizationDirectory().getOrganizationList()) {
//            if (organization instanceof PrisonerOrganization) {
//                o =organization;
//            }
//
//            Organization org = (Organization) o;
        if (org != null) {
            for (Prisoner p : org.getPrisonerDirectory().getPrisonerList()) {
                cbPrisonerName.addItem(p);
            }
        }
        cbRate.removeAllItems();

        cbRate.addItem("Amateure");
        cbRate.addItem("Noob");
        cbRate.addItem("Professional");
    }

    public void populateTable() {
        if (cbPrisonerName.getSelectedItem().equals("")) {
            JOptionPane.showMessageDialog(null, "Please select Prisoner Name");
            return;
        }
        Date d = new Date();

        DefaultTableModel model = (DefaultTableModel) tblSkillDetails.getModel();

        SimpleDateFormat sd = new SimpleDateFormat("MM-dd-yyyy");
        model.setRowCount(0);

        //comment below for testing
        for (Prisoner p : org.getPrisonerDirectory().getPrisonerList()) {
            for (Event e : p.getEventDirectory().getEventDirectory()) {
                if (p.getPrisonerName().equals(cbPrisonerName.getSelectedItem().toString())) {
//                if (e.getEventEndDate().before(d)) {
//                    e.getSkill().setSkillStatus("Training Completed");
//                } else if (e.getEventDate().before(d)) {
//                    e.getSkill().setSkillStatus("Training InProgress");
//                } else {
//                    e.getSkill().setSkillStatus("Training yet to start");
                    //temp
                    //e.getSkill().setSkillStatus("Training Completed");
//                }
                    if (e.getSkill().getSkillStatus() == null) {
                        e.getSkill().setSkillStatus("Training Completed");
                    } else if (e.getSkill().getSkillStatus().equals("Evaluation InProgress")) {

                    } else if (e.getSkill().getSkillStatus().equals("Evaluation Completed")) {

                    }
                }
            }
        }
        //
        for (Prisoner p : org.getPrisonerDirectory().getPrisonerList()) {
            if (cbPrisonerName.getSelectedItem().toString().equals(p.getPrisonerName())) {
                for (Event e : p.getEventDirectory().getEventDirectory()) {
                    if (e.getSkill().getSkillStatus().equals("Training Completed") || e.getSkill().getSkillStatus().equals("Evaluation InProgress") || e.getSkill().getSkillStatus().equals("Evaluation Completed")) {
                        Object[] row = new Object[4];
                        row[0] = e.getSkill().getSkillName();
                        row[1] = sd.format(e.getEventEndDate());
                        row[2] = e.getSkill().getSkillStatus();
                        row[3] = e.getSkill().getSkillLevel();
                        model.addRow(row);
                    }
                }
            }
        }
    }

    public void populateTableEvaluated() {
        int selectedRow = tblSkillDetails.getSelectedRow();

        if (selectedRow < 0) {
            JOptionPane.showMessageDialog(null, "Please select row from the table");
            return;
        }
        if (cbRate.getSelectedItem().equals("")) {
            JOptionPane.showMessageDialog(null, "Please select Rating");
            return;
        }
        Date d = new Date();

        SimpleDateFormat sd = new SimpleDateFormat("MM-dd-yyyy");

        String skillName = tblSkillDetails.getValueAt(selectedRow, 0).toString();
        for (Prisoner p : org.getPrisonerDirectory().getPrisonerList()) {
            if (cbPrisonerName.getSelectedItem().toString().equals(p.getPrisonerName())) {
                for (Event e : p.getEventDirectory().getEventDirectory()) {
                    if (skillName.equals(e.getSkill().getSkillName())) {
                        if (e.getSkill().getSkillStatus().equals("Evaluation InProgress")) {
                            e.getSkill().setSkillStatus("Evaluation Completed");
                            e.getSkill().setSkillLevel(cbRate.getSelectedItem().toString());
                            p.getSkillDirectory().createSkills(e.getSkill());
                        } else if (e.getSkill().getSkillStatus().equals("Training Completed")) {
                            JOptionPane.showMessageDialog(null, "Start Evaluation first.");
                            populateTable();
                            return;
                        } else if (e.getSkill().getSkillStatus().equals("Training InProgress")) {
                            JOptionPane.showMessageDialog(null, "Training InProgress");
                            populateTable();
                            return;
                        } else if (e.getSkill().getSkillStatus().equals("Evaluation Completed")) {
                            JOptionPane.showMessageDialog(null, "Evaluation already done");
                            populateTable();
                            return;
                        }
                    }
                }
            }
        }
        populateTable();
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        cbPrisonerName = new javax.swing.JComboBox();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblSkillDetails = new javax.swing.JTable();
        btnStartEvaluation = new javax.swing.JButton();
        btnEndEvaluation = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        cbRate = new javax.swing.JComboBox<>();
        jLabel3 = new javax.swing.JLabel();
        btnBack = new javax.swing.JButton();

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel1.setText("Prisoner Name:");

        cbPrisonerName.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        cbPrisonerName.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cbPrisonerName.addPopupMenuListener(new javax.swing.event.PopupMenuListener() {
            public void popupMenuCanceled(javax.swing.event.PopupMenuEvent evt) {
            }
            public void popupMenuWillBecomeInvisible(javax.swing.event.PopupMenuEvent evt) {
                cbPrisonerNamePopupMenuWillBecomeInvisible(evt);
            }
            public void popupMenuWillBecomeVisible(javax.swing.event.PopupMenuEvent evt) {
            }
        });

        tblSkillDetails.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Skill Name", "Skill Completion date", "Skill Status", "Skill level"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(tblSkillDetails);
        if (tblSkillDetails.getColumnModel().getColumnCount() > 0) {
            tblSkillDetails.getColumnModel().getColumn(0).setResizable(false);
            tblSkillDetails.getColumnModel().getColumn(1).setResizable(false);
            tblSkillDetails.getColumnModel().getColumn(2).setResizable(false);
            tblSkillDetails.getColumnModel().getColumn(3).setResizable(false);
        }

        btnStartEvaluation.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        btnStartEvaluation.setText("Start Evaluation");
        btnStartEvaluation.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnStartEvaluationActionPerformed(evt);
            }
        });

        btnEndEvaluation.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        btnEndEvaluation.setText("End Evaluation and Rate Skill");
        btnEndEvaluation.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEndEvaluationActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel2.setText("Rate:");

        cbRate.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        cbRate.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel3.setText("Evaluate Prisoner");

        btnBack.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        btnBack.setText("<< Back");
        btnBack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBackActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(117, 117, 117)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel1)
                                .addGap(57, 57, 57)
                                .addComponent(cbPrisonerName, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(btnStartEvaluation)
                            .addComponent(btnEndEvaluation)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel2)
                                .addGap(41, 41, 41)
                                .addComponent(cbRate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btnBack)
                        .addGap(118, 118, 118)
                        .addComponent(jLabel3)))
                .addContainerGap(158, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(26, 26, 26)
                        .addComponent(jLabel3))
                    .addComponent(btnBack))
                .addGap(53, 53, 53)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(cbPrisonerName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(68, 68, 68)
                .addComponent(btnStartEvaluation)
                .addGap(18, 18, 18)
                .addComponent(btnEndEvaluation)
                .addGap(23, 23, 23)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(cbRate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(105, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void cbPrisonerNamePopupMenuWillBecomeInvisible(javax.swing.event.PopupMenuEvent evt) {//GEN-FIRST:event_cbPrisonerNamePopupMenuWillBecomeInvisible
        // TODO add your handling code here:
        populateTable();
    }//GEN-LAST:event_cbPrisonerNamePopupMenuWillBecomeInvisible

    private void btnEndEvaluationActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEndEvaluationActionPerformed
        // TODO add your handling code here:
        populateTableEvaluated();
    }//GEN-LAST:event_btnEndEvaluationActionPerformed

    private void btnStartEvaluationActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnStartEvaluationActionPerformed
        // TODO add your handling code here:

        int selectedRow = tblSkillDetails.getSelectedRow();

        if (selectedRow < 0) {
            JOptionPane.showMessageDialog(null, "Please select row from the table");
            return;
        }
        String skillName = tblSkillDetails.getValueAt(selectedRow, 0).toString();
        if (tblSkillDetails.getValueAt(selectedRow, 2).equals("Training Completed")) {
            for (Prisoner p : org.getPrisonerDirectory().getPrisonerList()) {
                for (Event e : p.getEventDirectory().getEventDirectory()) {
                    if (cbPrisonerName.getSelectedItem().toString().equals(p.getPrisonerName()) && skillName.equals(e.getSkill().getSkillName()) && e.getSkill().getPrisonerName().equals(p.getPrisonerName())) {
                        e.getSkill().setSkillStatus("Evaluation InProgress");
                    }
                }
            }
        } else if (tblSkillDetails.getValueAt(selectedRow, 2).equals("Training InProgress")) {
            JOptionPane.showMessageDialog(null, "Training InProgress, can not evaluate this");
        } else if (tblSkillDetails.getValueAt(selectedRow, 2).equals("Evaluation InProgress")) {
            JOptionPane.showMessageDialog(null, "Evaluation already InProgress");
        } else if (tblSkillDetails.getValueAt(selectedRow, 2).equals("Evaluation Completed")) {
            JOptionPane.showMessageDialog(null, "Evaluation already Completed");
        }
        populateTable();
    }//GEN-LAST:event_btnStartEvaluationActionPerformed

    private void btnBackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackActionPerformed
        // TODO add your handling code here:
        userProcessContainer.remove(this);
        CardLayout layout = (CardLayout) userProcessContainer.getLayout();
        layout.previous(userProcessContainer);
    }//GEN-LAST:event_btnBackActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBack;
    private javax.swing.JButton btnEndEvaluation;
    private javax.swing.JButton btnStartEvaluation;
    private javax.swing.JComboBox cbPrisonerName;
    private javax.swing.JComboBox<String> cbRate;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tblSkillDetails;
    // End of variables declaration//GEN-END:variables

}
