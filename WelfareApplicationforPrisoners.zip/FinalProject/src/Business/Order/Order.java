/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Order;

import Business.Customer.Customer;
import Business.Product.Product;
import Business.UserAccount.UserAccount;
import java.util.ArrayList;
import java.util.Date;

/**
 *
 * @author rishi
 */
public class Order {
 
    private int orderId;
    private ArrayList<OrderItem> order;

    private String status;
    private Date issueDate;
    private Date completionDate;
    private Date shippingDate;
    private String shippingmessage;
    private String finishmessage;

    public String getShippingmessage() {
        return shippingmessage;
    }

    public void setShippingmessage(String shippingmessage) {
        this.shippingmessage = shippingmessage;
    }

    public String getFinishmessage() {
        return finishmessage;
    }

    public void setFinishmessage(String issuemessage) {
        this.finishmessage = issuemessage;
    }
    private int orderNumber;
    private static int count = 0;
    private Customer customer;
    private UserAccount userAccount;
    private int orderValue;
   
    public Order()
    {
        order = new ArrayList<OrderItem>();
        count++;
        orderId =count;
        
    }
    public void setOrder(int c)
    {
        count=c;
    }
    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public int getOrderValue() {
        return orderValue;
    }
    
    public void setOrderValue(int orderValue) {
        this.orderValue = orderValue;
    }

    public UserAccount getUserAccount() {
        return userAccount;
    }

    public void setUserAccount(UserAccount userAccount) {
        this.userAccount = userAccount;
    }
    
    
    public ArrayList<OrderItem> getOrder() {
        return order;
    }

    public int getOrderId() {
        return orderId;
    }

    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }

    public static int getCount() {
        return count;
    }

    public static void setCount(int count) {
        Order.count = count;
    }
 
    
    public void setOrder(ArrayList<OrderItem> order) {
        this.order = order;
    }
    public int getOrderNumber() {
        return orderNumber;
    }
 
    public void setOrderNumber(int orderNumber) {
        this.orderNumber = orderNumber;
    }
   
 
    public String getStatus() {
        return status;
    }
 
    public void setStatus(String status) {
        this.status = status;
    }
 
    public Date getIssueDate() {
        return issueDate;
    }
 
    public void setIssueDate(Date issueDate) {
        this.issueDate = issueDate;
    }
 
    public Date getCompletionDate() {
        return completionDate;
    }
 
    public void setCompletionDate(Date completionDate) {
        this.completionDate = completionDate;
    }
 
    public Date getShippingDate() {
        return shippingDate;
    }
 
    public void setShippingDate(Date shippingDate) {
        this.shippingDate = shippingDate;
    }
   
     public void addOrderItem(OrderItem oi) {
        
        order.add(oi);
        
    }
   
    public void removeOrderItem(OrderItem oi)
    {
        order.remove(oi);
    }
    
    @Override
    
    public String toString()
   {
       return Integer.toString(orderId);
   }
    
}

   
