/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Order;

import Business.Product.Product;
import java.util.ArrayList;

/**
 *
 * @author rishi
 */
public class MasterOrderCatalog
{
    private ArrayList<Order> masterOrderCatalog;
    
     public void addOrder(Order order) 
     { 
        masterOrderCatalog.add(order);
      }

    public ArrayList<Order> getMasterOrderCatalog() {
        return masterOrderCatalog;
    
}
}
