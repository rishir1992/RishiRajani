/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Job;

import java.util.ArrayList;

/**
 *
 * @author Kinjal
 */
public class JobDirectory {
    private ArrayList<Job> jobDirectory;

    public JobDirectory() {
        jobDirectory = new ArrayList<>();
    }

    public ArrayList<Job> getJobDirectory() {
        return jobDirectory;
    }

    public void setJobDirectory(ArrayList<Job> jobDirectory) {
        this.jobDirectory = jobDirectory;
    }

    public void createJob(Job job){
        jobDirectory.add(job);
    }
    public void removeJob(Job job){
        jobDirectory.remove(job);
    }
}
