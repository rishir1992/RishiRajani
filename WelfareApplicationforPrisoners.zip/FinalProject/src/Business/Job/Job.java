/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Job;

import Business.Prisoner.Prisoner;
import Business.Prisoner.PrisonerDirectory;
import Business.Product.Product;
import java.util.ArrayList;

/**
 *
 * @author Kinjal
 */
public class Job {
    private int jobID;
    private Product product;
    private ArrayList<Prisoner> prisonerDirectory;
    private int quantity;
    private String jobStatus;
    private String jobMarks;
    private static int count=0;
    
    
    public Job() {
        count++;
        prisonerDirectory=new ArrayList<>();
        jobID=count;
    }
    
    public Product getProduct() {
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }

    public ArrayList<Prisoner> getPrisonerDirectory() {
        return prisonerDirectory;
    }

    public void setPrisonerDirectory(ArrayList<Prisoner> prisonerDirectory) {
        this.prisonerDirectory = prisonerDirectory;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public String getJobStatus() {
        return jobStatus;
    }

    public void setJobStatus(String jobStatus) {
        this.jobStatus = jobStatus;
    }

    public int getJobID() {
        return jobID;
    }

    public void setJobID(int jobID) {
        this.jobID = jobID;
    }

    public String getJobMarks() {
        return jobMarks;
    }

    public void setJobMarks(String jobMarks) {
        this.jobMarks = jobMarks;
    }

    public void createPrisoner(Prisoner prisoner){
        prisonerDirectory.add(prisoner);
    }
    
    public void removePrisoner(Prisoner prisoner)
    {
        prisonerDirectory.remove(prisoner);
    }
    
    @Override 
    
    public String toString()
    {
        return jobStatus;
    }
}
