/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

import Business.Customer.Customer;
import Business.Enterprise.Enterprise;
import Business.Network.Network;
import Business.Order.Order;
import Business.Organization.Organization;
import Business.Product.Product;
import Business.Role.CustomerRole;
import Business.Role.JudgeRole;
import Business.Role.LawyerRole;
import Business.Role.PDMManagerRole;
import Business.Role.PrisonerRole;
import Business.Role.Role;
import static Business.Role.Role.RoleType.SystemAdmin;
import Business.Role.SystemAdmin;
import Business.Role.WardenRole;
import Business.Skills.SkillDirectory;
import Business.Skills.Skills;
import Business.UserAccount.UserAccount;
import java.util.ArrayList;
import java.util.HashSet;

/**
 *
 * @author Kinjal
 */
public class EcoSystem extends Organization{
    private static EcoSystem business;
    private ArrayList<Network> networkList;
    private SkillDirectory skillDirectory;
    private ArrayList<Product> productDirectory;
     private ArrayList<Customer> customerDirectory;
     private ArrayList<Order> masterOrderCatalog;

    public static EcoSystem getInstance() {
        if (business == null) {
            business = new EcoSystem();
        }
        return business;
    }

    private EcoSystem() 
    {
        super(null);
        networkList = new ArrayList<>();
        skillDirectory= new SkillDirectory();
        productDirectory = new ArrayList<>();
        customerDirectory = new ArrayList<>();
        masterOrderCatalog = new ArrayList<>();
    }

    public ArrayList<Order> getMasterOrderCatalog() {
        return masterOrderCatalog;
    }

    public ArrayList<Network> getNetworkList() {
        return networkList;
    }
    
    public static void setInstance(EcoSystem system) {
        business=system;
    } 

    public SkillDirectory getSkillDirectory() {
        return skillDirectory;
    }

    public Network createAndAddNetwork() 
    {
        Network network = new Network();
        networkList.add(network);
        return network;
    }
    
     public void createProduct(Product p)
     {
        productDirectory.add(p);
        //return p;
     }
     public void deleteProduct(Product p)
     {
        productDirectory.remove(p);
        //return p;
     }
     
     public Customer createCustomer()
     {
        Customer cutomer = new Customer();
        customerDirectory.add(cutomer);
        return cutomer;
     }

    public ArrayList<Product> getProductDirectory() {
        return productDirectory;
    }

    public ArrayList<Customer> getCustomerDirectory() {
        return customerDirectory;
    }
    public void addOrder(Order order) 
        { 
        masterOrderCatalog.add(order);
        }
     
    
    @Override
    public HashSet<Role> getSupportedRole() {
        roles.add(new SystemAdmin());
        roles.add(new CustomerRole());
        roles.add(new JudgeRole());
        roles.add(new LawyerRole());
        roles.add(new PDMManagerRole());
        roles.add(new WardenRole());
        roles.add(new PrisonerRole());
        return roles;
    }

    public static boolean checkIfUsernameIsUnique(String username) {

      //  if (!this.getUserAccountDirectory().checkIfUsernameIsUnique(username)) {
             for (Network network : business.getNetworkList()) {
                 
                for (Enterprise enterprise : network.getEnterpriseDirectory().getEnterpriseList()) {
                    for (UserAccount ua : enterprise.getUserAccountDirectory().getUserAccountList()) {
                        if(ua.getUsername().equals(username)){
                            return false;
                        }
                    }
                    
                        for (Organization organization : enterprise.getOrganizationDirectory().getOrganizationList()) {
                            for (UserAccount ua : organization.getUserAccountDirectory().getUserAccountList()) {
                                 if(ua.getUsername().equals(username)){
                            return false;
                        }
                    }
                            }
                        }
                    }
            
      //  }

       

        return true;
    }
}
