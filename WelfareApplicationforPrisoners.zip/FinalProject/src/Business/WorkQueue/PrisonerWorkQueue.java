/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.WorkQueue;

import Business.Event.Event;
import Business.Skills.Skills;

/**
 *
 * @author Kinjal
 */
public class PrisonerWorkQueue extends WorkRequest{
    
    private Skills skillApplied;
    private String Date;
    private Event event;

    public Skills getSkillApplied() {
        return skillApplied;
    }

    public void setSkillApplied(Skills skillApplied) {
        this.skillApplied = skillApplied;
    }

    public String getDate() {
        return Date;
    }

    public void setDate(String Date) {
        this.Date = Date;
    }

    public Event getEvent() {
        return event;
    }

    public void setEvent(Event event) {
        this.event = event;
    }
}
