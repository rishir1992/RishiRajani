/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.WorkQueue;

import Business.Lawyer.Lawyer;
import Business.Prisoner.Prisoner;

/**
 *
 * @author Kinjal
 */
public class CaseWorkRequest extends WorkRequest{
    private Prisoner prisoner;
    private String caseMessage;
    private String caseType;
    private boolean wardenRecommendation;
    private Lawyer lawyer;

    public Prisoner getPrisoner() {
        return prisoner;
    }

    public void setPrisoner(Prisoner prisoner) {
        this.prisoner = prisoner;
    }
    
    public String getCaseMessage() {
        return caseMessage;
    }

    public void setCaseMessage(String caseMessage) {
        this.caseMessage = caseMessage;
    }

    public Lawyer getLawyer() {
        return lawyer;
    }

    public void setLawyer(Lawyer lawyer) {
        this.lawyer = lawyer;
    }

    public String getCaseType() {
        return caseType;
    }

    public void setCaseType(String caseType) {
        this.caseType = caseType;
    }

    public boolean isWardenRecommendation() {
        return wardenRecommendation;
    }

    public void setWardenRecommendation(boolean wardenRecommendation) {
        this.wardenRecommendation = wardenRecommendation;
    }
    
    
}
