/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Lawyer;

import Business.Employee.Employee;
import java.util.ArrayList;

/**
 *
 * @author rishi
 */
public class LawyerDirectory {
    
    private ArrayList<Lawyer> lawyerList;

    public LawyerDirectory() {
       lawyerList = new ArrayList<>();
    }

    public ArrayList<Lawyer> getLawyerList() {
        return lawyerList;
    }
    
    public void createLawyer(String name, int fees, int casesWon)
    {
        Lawyer lawyer = new Lawyer();
        lawyer.setName(name);
        lawyer.setFees(fees);
        lawyer.setNoOfCasesWon(casesWon);
        lawyerList.add(lawyer);
    }
    
}
