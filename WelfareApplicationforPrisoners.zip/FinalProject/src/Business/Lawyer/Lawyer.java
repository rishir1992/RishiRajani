/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Lawyer;
import Business.*;

/**
 *
 * @author rishi
 */
public class Lawyer 
{
    private String name;
    private int noOfCasesWon;
    private int fees;

    public String getName() 
    {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getNoOfCasesWon() {
        return noOfCasesWon;
    }

    public void setNoOfCasesWon(int noOfCasesWon) {
        this.noOfCasesWon = noOfCasesWon;
    }

    public int getFees() {
        return fees;
    }

    public void setFees(int fees) {
        this.fees = fees;
    }
   
    @Override
    public String toString()
    {
        return name;
    }
}
