/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Prisoner;

import java.util.ArrayList;

/**
 *
 * @author Kinjal
 */
public class PrisonerDirectory {
    private ArrayList<Prisoner> prisonerList;

    public PrisonerDirectory() {
        prisonerList = new ArrayList<>();
    }

    public ArrayList<Prisoner> getPrisonerList() {
        return prisonerList;
    }
    
    public Prisoner createPrisoner(String name){
        Prisoner prison = new Prisoner();
        prison.setPrisonerName(name);
        prisonerList.add(prison);
        return prison;
    }
}
