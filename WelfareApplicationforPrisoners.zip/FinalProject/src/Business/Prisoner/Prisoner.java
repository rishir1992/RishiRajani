/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Prisoner;

import Business.Event.EventDirectory;
import Business.Skills.SkillDirectory;
import java.util.Date;

/**
 *
 * @author Kinjal
 */
public class Prisoner {
    private int prisonerId;
    private String prisonerName;
    private Date admitDate;
    private Date releaseDate;
    private String crimeDescription;
    private String status;
    private boolean paroleApplied;
    private boolean onParole; 
    private boolean releaseApplied; 
    private int sentenceDuration;
    private int crimeLevel;
    private float totalPoints;
    private boolean maritialStatus  = false;
    private int noOfKids;
    private float mentalStabilityIndex;
    private int age;
    private int noOfComplains;
    private float goodBehaviourIndex;
    private int noOfJobs;
    private float jobPoints;
    private float totalEarnings;
    private boolean recommendation;

    public boolean isRecommendation() {
        return recommendation;
    }

    public void setRecommendation(boolean recommendation) {
        this.recommendation = recommendation;
    }

    public float getTotalEarnings() {
        return totalEarnings;
    }

    public void setTotalEarnings(float totalEarnings) {
        this.totalEarnings = totalEarnings;
    }

    public int getNoOfJobs() {
        return noOfJobs;
    }

    public void setNoOfJobs(int noOfJobs) {
        this.noOfJobs = noOfJobs;
    }

    public float getJobPoints() {
        return jobPoints;
    }

    public void setJobPoints(float jobPoints) {
        this.jobPoints = jobPoints;
    }
   

    public String getCrimeDescription() {
        return crimeDescription;
    }

    public void setCrimeDescription(String crimeDescription) {
        this.crimeDescription = crimeDescription;
    }

    public boolean isMaritialStatus() {
        return maritialStatus;
    }

    public void setMaritialStatus(boolean maritialStatus) {
        this.maritialStatus = maritialStatus;
    }

    public int getNoOfKids() {
        return noOfKids;
    }

    public void setNoOfKids(int noOfKids) {
        this.noOfKids = noOfKids;
    }

    public float getMentalStabilityIndex() {
        return mentalStabilityIndex;
    }

    public void setMentalStabilityIndex(float mentalStabilityIndex) {
        this.mentalStabilityIndex = mentalStabilityIndex;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public int getNoOfComplains() {
        return noOfComplains;
    }

    public void setNoOfComplains(int noOfComplains) {
        this.noOfComplains = noOfComplains;
    }

    public float getGoodBehaviourIndex() {
        return goodBehaviourIndex;
    }

    public void setGoodBehaviourIndex(float goodBehaviourIndex) {
        this.goodBehaviourIndex = goodBehaviourIndex;
    }
    
    
    private SkillDirectory skillDirectory;
    private EventDirectory eventDirectory;
    private static int count = 1;
    
    public Prisoner() {
        skillDirectory=new SkillDirectory();
        eventDirectory=new EventDirectory();
        prisonerId = count;
        count++;
    }
    
    public int getPrisonerId() {
        return prisonerId;
    }

    public void setPrisonerId(int prisonerId) {
        this.prisonerId = prisonerId;
    }

    public String getPrisonerName() {
        return prisonerName;
    }

    public void setPrisonerName(String prisonerName) {
        this.prisonerName = prisonerName;
    }

    public int getSentenceDuration() {
        return sentenceDuration;
    }

    public void setSentenceDuration(int sentenceDuration) {
        this.sentenceDuration = sentenceDuration;
    }

    public int getCrimeLevel() {
        return crimeLevel;
    }

    public void setCrimeLevel(int crimeLevel) {
        this.crimeLevel = crimeLevel;
    }

    public Date getAdmitDate() {
        return admitDate;
    }

    public void setAdmitDate(Date admitDate) {
        this.admitDate = admitDate;
    }

    public Date getReleaseDate() {
        return releaseDate;
    }

    public void setReleaseDate(Date releaseDate) {
        this.releaseDate = releaseDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public float getTotalPoints() {
        return totalPoints;
    }

    public void setTotalPoints(float totalPoints) {
        this.totalPoints = totalPoints;
    }

    public boolean isParoleApplied() {
        return paroleApplied;
    }

    public void setParoleApplied(boolean paroleApplied) {
        this.paroleApplied = paroleApplied;
    }

    public boolean isOnParole() {
        return onParole;
    }

    public void setOnParole(boolean onParole) {
        this.onParole = onParole;
    }

    public boolean isReleaseApplied() {
        return releaseApplied;
    }

    public void setReleaseApplied(boolean releaseApplied) {
        this.releaseApplied = releaseApplied;
    }

    
    public SkillDirectory getSkillDirectory() {
        return skillDirectory;
    }

    public void setSkillDirectory(SkillDirectory skillDirectory) {
        this.skillDirectory = skillDirectory;
    }

    public EventDirectory getEventDirectory() {
        return eventDirectory;
    }

    public void setEventDirectory(EventDirectory eventDirectory) {
        this.eventDirectory = eventDirectory;
    }
    
    @Override
    public String toString()
    {
        return prisonerName;
    }
    
}
