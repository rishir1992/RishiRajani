/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Event;

import Business.Skills.Skills;
import java.util.Date;

/**
 *
 * @author Kinjal
 */
public class Event {
    private Skills skill;
    private Date eventDate;
    private Date eventEndDate;
    private int seatAvailable;

    public Skills getSkill() {
        return skill;
    }

    public void setSkill(Skills skill) {
        this.skill = skill;
    }

    public Date getEventDate() {
        return eventDate;
    }

    public void setEventDate(Date eventDate) {
        this.eventDate = eventDate;
    }

    public Date getEventEndDate() {
        return eventEndDate;
    }

    public void setEventEndDate(Date eventEndDate) {
        this.eventEndDate = eventEndDate;
    }
//    @Override
//    public String toString()
//    {
//        return skill.getSkillName();
//    }

    public int getSeatAvailable() {
        return seatAvailable;
    }

    public void setSeatAvailable(int seatAvailable) {
        this.seatAvailable = seatAvailable;
    }
    
    @Override
    public String toString()
    {
        return Integer.toString(seatAvailable);
    }
}
