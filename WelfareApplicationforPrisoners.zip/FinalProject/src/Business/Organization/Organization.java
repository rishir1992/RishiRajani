/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Organization;

import Business.Employee.EmployeeDirectory;
import Business.Event.EventDirectory;
import Business.Job.JobDirectory;
import Business.Judge.JudgeDirectory;
import Business.Lawyer.LawyerDirectory;
import Business.Prisoner.PrisonerDirectory;
import Business.Role.Role;
import Business.UserAccount.UserAccountDirectory;
import Business.WorkQueue.PrisonerWorkQueue;
import Business.WorkQueue.WorkQueue;
import java.util.HashSet;

/**
 *
 * @author Kinjal
 */
public abstract class Organization {
    private String name;
    private WorkQueue workQueue;
    private PrisonerWorkQueue prisonWorkQueue;
    private EmployeeDirectory employeeDirectory;
    private UserAccountDirectory userAccountDirectory;
    private PrisonerDirectory prisonerDirectory;
    private EventDirectory eventDirectory;
    private JobDirectory jobDirectory;
    private LawyerDirectory lawyerDirectory;
    private JudgeDirectory judgeDirectory;
    private int organizationID;
    private static int counter=0;
    public HashSet<Role> roles;
    
    public enum Type{
        Judge("Judge Organization"),Prison("Prison Organization"), Warden("Warden Organization"), Lawyer("Lawyer Organization");
        private String value;
        private Type(String value) {
            this.value = value;
        }
        public String getValue() {
            return value;
        }
    }

    public Organization(String name) {
        this.name = name;
        workQueue = new WorkQueue();
        prisonWorkQueue=new PrisonerWorkQueue();
        employeeDirectory = new EmployeeDirectory();
        userAccountDirectory = new UserAccountDirectory();
        prisonerDirectory=new PrisonerDirectory();
        eventDirectory= new EventDirectory();
        jobDirectory=new JobDirectory();
        lawyerDirectory= new LawyerDirectory();
        judgeDirectory= new JudgeDirectory();
        organizationID = counter;
        roles = new HashSet<>();
        ++counter;
    }

    public abstract HashSet<Role> getSupportedRole();
    
    public UserAccountDirectory getUserAccountDirectory() {
        return userAccountDirectory;
    }

    public int getOrganizationID() {
        return organizationID;
    }

    public EmployeeDirectory getEmployeeDirectory() {
        return employeeDirectory;
    }

    public PrisonerDirectory getPrisonerDirectory() {
        return prisonerDirectory;
    }

    public EventDirectory getEventDirectory() {
        return eventDirectory;
    }

    public JobDirectory getJobDirectory() {
        return jobDirectory;
    }

    public void setJobDirectory(JobDirectory jobDirectory) {
        this.jobDirectory = jobDirectory;
    }

    public LawyerDirectory getLawyerDirectory() {
        return lawyerDirectory;
    }

    public void setLawyerDirectory(LawyerDirectory lawyerDirectory) {
        this.lawyerDirectory = lawyerDirectory;
    }

    public JudgeDirectory getJudgeDirectory() {
        return judgeDirectory;
    }

    public void setJudgeDirectory(JudgeDirectory judgeDirectory) {
        this.judgeDirectory = judgeDirectory;
    }
    
    public String getName() {
        return name;
    }

    public WorkQueue getWorkQueue() {
        return workQueue;
    }

    public PrisonerWorkQueue getPrisonWorkQueue() {
        return prisonWorkQueue;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setWorkQueue(WorkQueue workQueue) {
        this.workQueue = workQueue;
    }

    public void setPrisonWorkQueue(PrisonerWorkQueue prisonWorkQueue) {
        this.prisonWorkQueue = prisonWorkQueue;
    }

    @Override
    public String toString() {
        return name;
    }
}
