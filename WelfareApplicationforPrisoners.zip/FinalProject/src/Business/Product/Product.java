/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Product;

/**
 *
 * @author Kinjal
 */
public class Product {
    private int productId;
    private String productName;
    private int price;
    private int availaibility;
    private String description;
    private static int pCount=1;
    private String skillRequired;
    private String madeBy;
    private String netwrkName;
    
    public Product() {
        productId=pCount;
        pCount++;
    }  

    public String getNetwrkName() {
        return netwrkName;
    }

    public void setNetwrkName(String netwrkName) {
        this.netwrkName = netwrkName;
    }
    
    public int getAvailaibility() {
        return availaibility;
    }

    public void setAvailaibility(int availaibility) {
        this.availaibility = availaibility;
    }

    public int getProductId() {
        return productId;
    }

    public void setProductId(int productId) {
        this.productId = productId;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }


    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public static int getpCount() {
        return pCount;
    }

    public static void setpCount(int pCount) {
        Product.pCount = pCount;
    }

    public String getSkillRequired() {
        return skillRequired;
    }

    public void setSkillRequired(String skillRequired) {
        this.skillRequired = skillRequired;
    }

    public String getMadeBy() {
        return madeBy;
    }

    public void setMadeBy(String madeBy) {
        this.madeBy = madeBy;
    }
    
     @Override
    public String toString() {
        return productName;
    }
    
    
}
