/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Enterprise;

import Business.Role.PDMManagerRole;
import Business.Role.Role;
import java.util.HashSet;

/**
 *
 * @author Kinjal
 */
public class PDMEnterprise extends Enterprise{
      public PDMEnterprise(String name) {
        super(name, Enterprise.EnterpriseType.PDM);
    }

    @Override
    public HashSet<Role> getSupportedRole() {
         roles= new HashSet<>();
        roles.add(new PDMManagerRole());
        return roles;
    }
}
