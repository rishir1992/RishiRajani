/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Enterprise;

import Business.Role.PrisonerRole;
import Business.Role.Role;
import java.util.HashSet;

/**
 *
 * @author Kinjal
 */
public class PrisonEnterprise extends Enterprise{
    
   
    public PrisonEnterprise(String name,String postalCode,String State, Double lattitude, Double longitude) {
        super(name, Enterprise.EnterpriseType.Prison,postalCode, State,  lattitude,  longitude);
    }

    @Override
    public HashSet<Role> getSupportedRole() {
         roles= new HashSet<>();
        roles.add(new PrisonerRole());
        return roles;
    }
}
