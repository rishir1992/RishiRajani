/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Enterprise;

import java.util.ArrayList;

/**
 *
 * @author Kinjal
 */
public class EnterpriseDirectory {
  private ArrayList<Enterprise> enterpriseList;

    public EnterpriseDirectory() {
        enterpriseList = new ArrayList<>();
    }

    public ArrayList<Enterprise> getEnterpriseList() {
        return enterpriseList;
    }
    
    public Enterprise createAndAddEnterprise(String name, Enterprise.EnterpriseType type){
        Enterprise enterprise = null;
        if (type == Enterprise.EnterpriseType.Judicial){
            enterprise = new JudicialEnterprise(name);
            enterpriseList.add(enterprise);
        }
        else if (type == Enterprise.EnterpriseType.PDM){
            enterprise = new PDMEnterprise(name);
            enterpriseList.add(enterprise);
        }
//        else  if (type == Enterprise.EnterpriseType.Prison){
//            enterprise = new PrisonEnterprise(name);
//            enterpriseList.add(enterprise);
//        }
        return enterprise;
    }
    public Enterprise createAndAddPrisonEnterprise(String name, Enterprise.EnterpriseType type,String postalCode,String State, Double lattitude, Double longitude){
        Enterprise enterprise = null;
        if (type == Enterprise.EnterpriseType.Prison){
            enterprise = new PrisonEnterprise(name,postalCode,State,lattitude,longitude);
            enterpriseList.add(enterprise);
        }
        return enterprise;
    }
}
