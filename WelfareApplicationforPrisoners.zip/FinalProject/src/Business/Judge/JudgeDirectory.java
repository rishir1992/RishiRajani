/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Judge;

import Business.Lawyer.Lawyer;
import java.util.ArrayList;

/**
 *
 * @author rishi
 */
public class JudgeDirectory 
        
{
    private ArrayList<Judge> judgeList;
    
    public JudgeDirectory() 
    {
        this.judgeList = new ArrayList<>();
    }

    public ArrayList<Judge> getJudgeList() {
        return judgeList;
    }

    public void setJudgeList(ArrayList<Judge> judgeList) {
        this.judgeList = judgeList;
    }

    
    
      public void createJudge(String name)
    {
       Judge judge = new Judge();
       judge.setJudgeName(name);
        judgeList.add(judge);
    }  
}
