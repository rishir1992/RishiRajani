/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Judge;

/**
 *
 * @author rishi
 */
public class Judge {
    
    private int judgeId;
    private String judgeName;
  
    private static int jCount;

    public Judge() {
        judgeId=jCount;
    } 

    public int getJudgeId() {
        return judgeId;
    }

    public void setJudgeId(int judgeId) {
        this.judgeId = judgeId;
    }

    public String getJudgeName() {
        return judgeName;
    }

    public void setJudgeName(String judgeName) {
        this.judgeName = judgeName;
    }
    
    
    
}
