/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

import Business.Customer.Customer;
import Business.Employee.Employee;
import Business.Product.Product;
import Business.Role.CustomerRole;
import Business.Role.Role;
import Business.Role.SystemAdmin;
import Business.UserAccount.UserAccount;

/**
 *
 * @author Kinjal
 */
public class ConfigureASystem {   
    public static EcoSystem configure(){
        
        EcoSystem system = EcoSystem.getInstance();
        
        
//        Product p = new Product();
//        p.setProductName("Laptop");
//        p.setDescription("Dell laptop");
//        p.setPrice(1099);
//        p.setAvailaibility(100);
//        p.setSkillRequired("java");
//        p.setMadeBy("Boston");
//        system.createProduct(p);
//        
//        Product p1 = new Product();
//        p1.setProductName("iPhone");
//        p1.setDescription("iPhone X");
//        p1.setPrice(1099);
//        p1.setAvailaibility(100);
//        p1.setSkillRequired("html");
//        p1.setMadeBy("California");
//        system.createProduct(p1);
        
        //Create a network
        //create an enterprise
        //initialize some organizations
        //have some employees 
        //create user account
       
        Employee employee = system.getEmployeeDirectory().createEmployee("RRH");
        //Employee employee1 = system.getEmployeeDirectory().createEmployee("Rishi");
        
        UserAccount ua = system.getUserAccountDirectory().createUserAccount("admin", "admin", employee, new SystemAdmin(),null);
       // UserAccount ua1 = system.getUserAccountDirectory().createUserAccount("rishi", "rishi", employee1, new CustomerRole(),null);
        return system;
    }
    
}

