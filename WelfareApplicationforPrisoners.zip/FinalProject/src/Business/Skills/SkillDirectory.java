/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Skills;

import java.util.ArrayList;

/**
 *
 * @author Kinjal
 */
public class SkillDirectory {
    private ArrayList<Skills> skillDirectory;

    public SkillDirectory() {
        skillDirectory = new ArrayList<>();
    }

    public ArrayList<Skills> getSkillDirectory() {
        return skillDirectory;
    }

    public void setSkillDirectory(ArrayList<Skills> skillDirectory) {
        this.skillDirectory = skillDirectory;
    }

    public void createSkills(Skills skill){
        skillDirectory.add(skill);
    }
}
