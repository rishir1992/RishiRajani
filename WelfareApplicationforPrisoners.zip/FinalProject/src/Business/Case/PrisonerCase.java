/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Case;

import Business.Prisoner.Prisoner;

/**
 *
 * @author rishi
 */
public class PrisonerCase 
{
    private Prisoner prisoner;
    private String message;
    private String caseType;
    private boolean wardenRecommendation;

    public Prisoner getPrisoner() {
        return prisoner;
    }

    public void setPrisoner(Prisoner prisoner) {
        this.prisoner = prisoner;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getCaseType() {
        return caseType;
    }

    public void setCaseType(String caseType) {
        this.caseType = caseType;
    }

    public boolean isWardenRecommendation() {
        return wardenRecommendation;
    }

    public void setWardenRecommendation(boolean wardenRecommendation) {
        this.wardenRecommendation = wardenRecommendation;
    }
    
    
    
}
